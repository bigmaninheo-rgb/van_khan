from pathlib import Path

from data.database import VanKhanDatabase


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    pdf_path = root / "vankhan.pdf"
    db = VanKhanDatabase(pdf_path)
    current = db.get_quan_hanh_khien(2026)
    print(f"Năm 2026: {current.vuong_hieu} - {current.hanh_binh} - {current.phan_quan}")


if __name__ == "__main__":
    main()
